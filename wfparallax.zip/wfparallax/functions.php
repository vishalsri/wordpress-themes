<?php

/*
 * Loads the Options Panel
 *
 * If you're loading from a child theme use stylesheet_directory
 * instead of template_directory
 */


@define( 'PARENT_DIR', get_template_directory() );
@define( 'CHILD_DIR', get_stylesheet_directory() );
@define( 'PARENT_URL', get_template_directory_uri() );
@define( 'CHILD_URL', get_stylesheet_directory_uri() );

define( 'RWMB_URL', trailingslashit( PARENT_DIR . '/includes/lib/meta-box' ) );
define( 'RWMB_DIR', trailingslashit( PARENT_DIR . '/includes/lib/meta-box' ) );

require_once ( RWMB_URL . 'meta-box.php' );
include_once(RWMB_URL . 'meta-boxes.php'); 
 
define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once dirname( __FILE__ ) . '/inc/options-framework.php';

// Loads options.php from child or parent theme
$optionsfile = locate_template( 'options.php' );
load_template( $optionsfile );

/*
 * This is an example of how to add custom scripts to the options panel.
 * This one shows/hides the an option when a checkbox is clicked.
 *
 * You can delete it if you not using that option
 */
add_action( 'optionsframework_custom_scripts', 'optionsframework_custom_scripts' );

function optionsframework_custom_scripts() { ?>

<script type="text/javascript">
jQuery(document).ready(function() {

	jQuery('#logo_showhidden').click(function() {
  		jQuery('#section-logo_text_hidden').fadeToggle(400);
	});

	if (jQuery('#logo_showhidden:checked').val() !== undefined) {
		jQuery('#section-logo_text_hidden').show();
	}
	jQuery('#logo_img_showhidden').click(function() {
  		jQuery('#section-logo_img_upload_hidden').fadeToggle(400);
	});

	if (jQuery('#logo_img_showhidden:checked').val() !== undefined) {
		jQuery('#section-logo_img_upload_hidden').show();
	}

});
</script>

<?php
}

/*
 * This is an example of filtering menu parameters
 */

/*
function prefix_options_menu_filter( $menu ) {
	$menu['mode'] = 'menu';
	$menu['page_title'] = __( 'Hello Options', 'textdomain');
	$menu['menu_title'] = __( 'Hello Options', 'textdomain');
	$menu['menu_slug'] = 'hello-options';
	return $menu;
}

add_filter( 'optionsframework_menu', 'prefix_options_menu_filter' );
*/

include_once(PARENT_DIR . '/includes/theme-init.php');

function WFParallax_scripts() {
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
}
add_action( 'wp_enqueue_scripts', 'WFParallax_scripts' );

function WFParallax_ajax_script(){
	 wp_localize_script( 'WF-parallax-ajax', 'ajax_script', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )) );
     wp_enqueue_script( 'WF-parallax-ajax', get_template_directory_uri().'/inc/js/ajax.js', 'jquery', true);

}
add_action('admin_enqueue_scripts', 'WFParallax_ajax_script');

function WF_parallax_get_my_option(){
	require get_template_directory() . '/inc/ajax.php';
	die();
}

add_action("wp_ajax_get_my_option", "WF_parallax_get_my_option");
