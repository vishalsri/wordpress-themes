<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till body
 *
 * @package WordPress
 * @subpackage WFParallax
 * @since WFParallax 1.0.0
 *
 */
?>
<?php
	global $theme_options;
	$theme_options  = get_option( 'wf_parallax');  
//echo "<pre>"; print_r($theme_options); echo "</pre>"; die("File name : ".__FILE__ . "Line no ". __LINE__);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="format-detection" content="telephone=no"/>
<title>
<?php
	if ( is_category() ) {
		echo __('Category Archive for &quot;', 'WFParallax'); single_cat_title(); echo __('&quot; | ', 'WFParallax'); bloginfo( 'name' );
	} elseif ( is_tag() ) {
		echo __('Tag Archive for &quot;', 'WFParallax'); single_tag_title(); echo __('&quot; | ', 'WFParallax'); bloginfo( 'name' );
	} elseif ( is_archive() ) {
		wp_title(''); echo __(' Archive | ', 'WFParallax'); bloginfo( 'name' );
	} elseif ( is_search() ) {
		echo __('Search for &quot;', 'WFParallax').wp_specialchars($s).__('&quot; | ', 'WFParallax'); bloginfo( 'name' );
	} elseif ( is_home() || is_front_page()) {
		bloginfo( 'name' ); echo ' | '; bloginfo( 'description' );
	}  elseif ( is_404() ) {
		echo __('Error 404 Not Found | ', 'WFParallax'); bloginfo( 'name' );
	} elseif ( is_single() ) {
		wp_title('');
	} else {
		echo wp_title( ' | ', false, 'right' ); bloginfo( 'name' );
	} 
?>
</title>
<?php if ($theme_options['responsive'] ==="yes"){ ?>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php } ?>
<?php if (!empty($theme_options['favicon']['url'])) { ?>
	<link rel="icon" href="<?php echo $theme_options['favicon']['url']; ?>" type="image/x-icon" />
	<link rel="shortcut icon" href="<?php echo $theme_options['favicon']['url']; ?>" type="image/x-icon" />
	<link rel="apple-touch-icon" href="<?php echo $theme_options['favicon']['url']; ?>"/>
<?php } else { ?>
	<link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="<?php bloginfo( 'template_url' ); ?>/images/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="<?php bloginfo( 'template_url' ); ?>/images/favicon.ico"/>
<?php } ?>

<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
<!--[if lt IE 7 ]><html class="ie ie6" <?php language_attributes();?>> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" <?php language_attributes();?>> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" <?php language_attributes();?>> <![endif]-->
<!--[if IE 9 ]><html class="ie ie9" <?php language_attributes();?>> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><html <?php language_attributes();?>><![endif]-->
<!--[if !IE]><html <?php language_attributes();?>><![endif]-->
<!--[if lt IE 9]>
<div style=' clear: both; text-align:center; position: relative;'>
	<a href="http://windows.microsoft.com/en-US/internet-explorer/..">
		<img src="<?php bloginfo( 'template_url' ); ?>/images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820"
			 alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."/>
	</a>
</div>
<script src="<?php bloginfo( 'template_url' ); ?>/js/html5shiv.js"></script>
<![endif]-->
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'atom_url' ); ?>" />
<?php if(is_search()) { ?>
	<meta name="robots" content="noindex, nofollow" /> 
<?php }?>
<?php if(is_archive() && !is_category()){ ?>
	<meta name="robots" content="noindex" />
<?php } ?>

<?php if (!empty($theme_options['header-code'])) { ?>
<?php echo $theme_options['header-code']; ?>
<?php } ?>
<style>
<?php if (!empty($theme_options['custom-css'])) { ?>
<?php echo $theme_options['custom-css']; ?>
<?php } ?>
</style>
<?php if (!empty($theme_options['header-metas'])) { ?>
<?php echo $theme_options['header-metas']; ?>
<?php } ?>
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> data-spy="scroll" data-target=".navbar" data-offset="50" >
 <!--------------------------Header Section Start-------------------------->
 <header>
        <div class="header-top navbar-fixed-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-sm-2 col-md-2 col-xs-2">
                        <div class="logo text-left hvr-bob">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                               <?php if($theme_options['logo'] === "image"): ?>
									<img src="<?php echo $theme_options['logo_img_upload']; ?>" alt="logo" class="img-thumbnail wow fadeInDown" />
									<?php else: ?>
								<!--	<img src="<?php //bloginfo('template_url') ?>/images/logo.png" alt="logo" class="img-thumbnail wow fadeInDown" />-->
									<h2><?php echo $theme_options['logo_text']; ?></h2>
									<?php endif; ?>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-10 col-sm-10 col-md-10 col-xs-10">
                        <nav class="navbar navbar-inverse">
                            <div class="container-fluid">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="collapse navbar-collapse" id="myNavbar"> 
                                    <?php  
										$sections = of_get_option('parallax_section');
										
										if((of_get_option('enable_parallax') == 1 && of_get_option('enable_parallax_nav') == 1) || (is_page_template('home-page.php') && of_get_option('enable_parallax_nav') == 1)):
									?>
									  <ul class="nav navbar-nav navbar-right">
										<?php
										$home_text = of_get_option('home_text');
									       
										if(!empty($home_text)) : 
											
											?>
											<li class="current"><a href="<?php echo esc_url( home_url( '/' ) ); ?>#"><?php echo esc_html($home_text); ?></a></li>
										<?php endif;
										if(!empty($sections)):
										foreach ($sections as $single_sections): 
											if($single_sections['layout'] != "action_template" && $single_sections['layout'] != "blank_template" && $single_sections['layout'] != "googlemap_template" && !empty($single_sections['page'])) :
												if(function_exists('pll_get_post')){
													$title_id = pll_get_post($single_sections['page']);
													$title = empty($title_id) ? get_the_title($single_sections['page']) : get_the_title($title_id);
												}else{
													$title = get_the_title($single_sections['page']); 
												}	
												?>
												<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>#section-<?php echo $single_sections['page']; ?>"><?php echo esc_html($title); ?></a></li>
											<?php 
											endif;
										endforeach; 
										endif; ?>
									</ul>
									<?php	else:  ?>
										<?php 
												wp_nav_menu(
													array( 
														'theme_location' => 'header', 
														'menu_class' => 'nav navbar-nav' ,
														'depth' =>1
													)
												);
											?>
									<?php endif; ?>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--------------------------Header Section End-------------------------->
	<?php 
	//$WFParallax_show_slider = of_get_option('show_slider') ;
	//$content_class = "";
	//if(empty($WFParallax_show_slider) || $WFParallax_show_slider == "no"):
		//$content_class = "no-slider";
	//endif;
	?>
	<!--<div id="content" class="site-content <?php //echo esc_attr($content_class); ?>">-->
	<?php 
	//if(is_home() || is_front_page()) :
		//do_action('WFParallax_bxslider'); 
	//endif; 
	?> 
