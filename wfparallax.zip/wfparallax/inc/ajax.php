<?php	
	
	// Parallax Defaults
	$parallax_defaults = NULL;

	// Pull all the pages into an array
	$options_pages_obj = get_pages('sort_column=post_parent,menu_order');

	$options_categories_obj = get_categories();

	$countsettings = esc_attr( $_REQUEST['count_section'] );
?>	

<div class="sub-option clearfix" data-id="<?php echo $countsettings; ?>">
<h3 class="title"><?php _e('Page Title:', 'wf-parallax') ?> <span></span><div class="section-toggle"><i class="fa fa-chevron-down"></i></div></h3>
<div class="sub-option-inner">

<div class="inline-label">
<label><?php _e('Page', 'wf-parallax') ?></label>
<select class="parallax_section_page" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][page]" class="of-input">
<option value=""><?php _e('Select a page:', 'wf-parallax') ?></option>
<?php foreach ($options_pages_obj as $page) { ?>
	<option value="<?php echo absint($page->ID); ?>"><?php echo esc_html($page->post_title); ?></option>
<?php } ?>
</select>
</div>

<div class="color-picker inline-label">
<label><?php _e('Font Color', 'wf-parallax') ?></label>
<input name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][font_color]" class="of-color" type="text">
</div>

<div class="color-picker inline-label">
<label><?php _e('Background Color', 'wf-parallax') ?></label>
<input name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][color]" class="of-color" type="text">
</div>

<div class="inline-label">
<label><?php _e('Layout', 'wf-parallax') ?></label>
<select class="of-section of-section-layout" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][layout]">
	<option value="default_template"><?php _e('Default Section', 'wf-parallax') ?></option>
	<option value="features_template"><?php _e('Features Section', 'wf-parallax') ?></option>
	<option value="pricing_template"><?php _e('Pricing Section', 'wf-parallax') ?></option>
	<option value="contactus_template"><?php _e('Contactus Section', 'wf-parallax') ?></option>
	<option value="about_template"><?php _e('About Section', 'wf-parallax') ?></option>
	<option value="service_template"><?php _e('Service Section', 'wf-parallax') ?></option>
	<option value="team_template"><?php _e('Team Section', 'wf-parallax') ?></option>
	<option value="portfolio_template"><?php _e('Portfolio Section', 'wf-parallax') ?></option>
	<option value="testimonial_template"><?php _e('Testimonial Section', 'wf-parallax') ?></option>
	<option value="blog_template"><?php _e('Blog Section', 'wf-parallax') ?></option>
	<option value="action_template"><?php _e('Call to Action Section', 'wf-parallax') ?></option>
	<option value="googlemap_template"><?php _e('Google Map Section', 'wf-parallax') ?></option>
	<option value="blank_template"><?php _e('Blank Section', 'wf-parallax') ?></option>
</select> 
</div>

<div class="inline-label toggle-category" style="display:none">
<label class=""><?php _e('Category', 'wf-parallax') ?></label>
<select name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][category]" class="of-input">
	<option value=""><?php _e('Select a Category:', 'wf-parallax') ?></option>
<?php foreach ($options_categories_obj as $category) { ?>
	<option value="<?php echo $category->cat_ID; ?>"><?php echo $category->cat_name; ?></option>
<?php } ?>
</select>
</div>

<div class="inline-label">
<label class=""><?php _e('Background Image', 'wf-parallax') ?></label>
<input type="text" placeholder="No file chosen" value="" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][image]" class="upload" id="parallax_section">
<input type="button" value="<?php _e('Upload', 'wf-parallax') ?>" class="upload-button button" id="upload-parallax_section">
<div id="parallax_section-image" class="screenshot"></div>
</div>


<div class="of-background-properties hide inline-label">
<label><?php _e('Background Settings', 'wf-parallax') ?></label>

<div class="background-settings">
<div class="clearfix">
<select id="parallax_section_repeat" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][repeat]" class="of-background of-background-repeat">
	<option value="no-repeat"><?php _e('No Repeat', 'wf-parallax') ?></option>
	<option value="repeat-x"><?php _e('Repeat Horizontally', 'wf-parallax') ?></option>
	<option value="repeat-y"><?php _e('Repeat Vertically', 'wf-parallax') ?></option>
	<option value="repeat"><?php _e('Repeat All', 'wf-parallax') ?></option>
</select>

<select id="parallax_section_position" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][position]" class="of-background of-background-position">
<option value="top left"><?php _e('Top Left', 'wf-parallax') ?></option>
<option value="top center"><?php _e('Top Center', 'wf-parallax') ?></option>
<option value="top right"><?php _e('Top Right', 'wf-parallax') ?></option>
<option value="center left"><?php _e('Middle Left', 'wf-parallax') ?></option>
<option value="center center"><?php _e('Middle Center', 'wf-parallax') ?></option>
<option value="center right"><?php _e('Middle Right', 'wf-parallax') ?></option>
<option value="bottom left"><?php _e('Bottom Left', 'wf-parallax') ?></option>
<option value="bottom center"><?php _e('Bottom Center', 'wf-parallax') ?></option>
<option value="bottom right"><?php _e('Bottom Right', 'wf-parallax') ?></option>
</select>

<select id="parallax_section_attachment" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][attachment]" class="of-background of-background-attachment">
<option value="scroll"><?php _e('Scroll Normally', 'wf-parallax') ?></option>
<option value="fixed"><?php _e('Fixed in Place', 'wf-parallax') ?></option>
</select>

<select id="parallax_section_size" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][size]" class="of-background of-background-size">
<option value="auto"><?php _e('Auto', 'wf-parallax') ?></option>
<option value="cover"><?php _e('Cover', 'wf-parallax') ?></option>
<option value="contain"><?php _e('Contain', 'wf-parallax') ?></option>
</select>
</div>
</div>

<div class="inline-label">
<label><?php _e('Overlay', 'wf-parallax') ?></label>
<select id="parallax_section_overlay" class="of-background of-background-overlay" name="wf_parallax[parallax_section][<?php echo $countsettings; ?>][overlay]">
<option value="overlay0"><?php _e('No Overlay', 'wf-parallax') ?></option>
<option value="overlay1"><?php _e('Small Dotted', 'wf-parallax') ?></option>
<option value="overlay2"><?php _e('Large Dotted', 'wf-parallax') ?></option>
<option value="overlay3"><?php _e('Light Black', 'wf-parallax') ?></option>
<option value="overlay4"><?php _e('Black Dotted', 'wf-parallax') ?></option>
</select>
</div>
</div>
<div class="remove-parallax button-primary"><?php _e('Remove', 'wf-parallax') ?></div>
</div>
</div>

