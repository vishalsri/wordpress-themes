jQuery(document).ready( function($) {
	jQuery('#add_new_section').click(function(){
		var count_section = jQuery('#parallax_count').val();
		count_section++;
		jQuery('#parallax_count').val(count_section);
		$.ajax({
		     url: ajaxurl,
		     data: ({
		     	'action' : 'get_my_option',
		     	'count_section' : count_section
		     }),
		     success: function(data) {
		      jQuery('#section-parallax_section .controls').append(data);
		      jQuery('.of-color').wpColorPicker();
		      
		      jQuery('.parallax_section_page').on('change',function(){
				var sled = jQuery(this).find("option:selected").text();
				jQuery(this).parents('.sub-option').find('.title span').text(sled);
			   });
		     }
		});
	});
});