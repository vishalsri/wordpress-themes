/**
 * Custom scripts needed for the colorpicker, image button selectors,
 * and navigation tabs.
 */

jQuery(document).ready(function($) {

	// Loads the color pickers
	jQuery('.of-color').wpColorPicker();

	// Image Options
	jQuery('.of-radio-img-img').click(function(){
		jQuery(this).parent().parent().find('.of-radio-img-img').removeClass('of-radio-img-selected');
		jQuery(this).addClass('of-radio-img-selected');
	});

	jQuery('.of-radio-img-label').hide();
	jQuery('.of-radio-img-img').show();
	jQuery('.of-radio-img-radio').hide();

	// Loads tabbed sections if they exist
	if ( jQuery('.nav-tab-wrapper').length > 0 ) {
		options_framework_tabs();
	}

	function options_framework_tabs() {

		var $group = jQuery('.group'),
			$navtabs = jQuery('.nav-tab-wrapper a'),
			active_tab = '';

		// Hides all the .group sections to start
		$group.hide();

		// If active tab is saved and exists, load it's .group
		if ( active_tab != '' && jQuery(active_tab).length ) {
			jQuery(active_tab).fadeIn();
			jQuery(active_tab + '-tab').addClass('nav-tab-active');
		} else {
			jQuery('.group:first').fadeIn();
			jQuery('.nav-tab-wrapper a:first').addClass('nav-tab-active');
		}

		// Bind tabs clicks
		$navtabs.click(function(e) {

			e.preventDefault();

			// Remove active class from all tabs
			$navtabs.removeClass('nav-tab-active');

			jQuery(this).addClass('nav-tab-active').blur();

			var selected = jQuery(this).attr('href');

			$group.hide();
			jQuery(selected).fadeIn();

		});
	}

	jQuery('#enable_parallax').click(function() {
  		jQuery('#section-sticky_header').fadeToggle(400);
	});

	if (jQuery('#enable_parallax:checked').val() == undefined) {
		jQuery('#section-sticky_header').show();
	}

	jQuery( "#section-parallax_section .controls" ).sortable({
		axis: "y"
	});
	jQuery( "#sub-option-inner" ).disableSelection();

	jQuery(document).on('click', '.section-toggle', function(){
		jQuery(this).parent('.title').next('.sub-option-inner').slideToggle();
	});

	jQuery('.parallax_section_page').on('change',function(){
		var sled = jQuery(this).find("option:selected").text();
		jQuery(this).parents('.sub-option').find('.title span').text(sled);
	}).change();

	jQuery(document).on('click','.remove-parallax', function(){
		var $this = jQuery(this);
		$this.parents('.sub-option').slideUp(800);
		setTimeout( function() {
      	$this.parents('.sub-option').remove();
		},750 );
	});

	jQuery('#section-parallax_section .of-section-layout').each(function() {
        var IntlayoutValue = jQuery(this).val();
        if (IntlayoutValue == 'service_template' || IntlayoutValue == 'team_template' || IntlayoutValue == 'testimonial_template' || IntlayoutValue == 'blog_template' || IntlayoutValue == 'portfolio_template' || layoutValue == 'features_template' || layoutValue == 'about_template' || layoutValue == 'pricing_template') {
            jQuery(this).parents('.sub-option-inner').find('.toggle-category').show();
        } else {
            jQuery(this).parents('.sub-option-inner').find('.toggle-category').hide();
        }
    });

    jQuery(document).on('change', '.of-section-layout', function() {
        var layoutValue = jQuery(this).val();
        if (layoutValue == 'service_template' || layoutValue == 'team_template' || layoutValue == 'testimonial_template' || layoutValue == 'blog_template' || layoutValue == 'portfolio_template' || layoutValue == 'features_template' || layoutValue == 'about_template' || layoutValue == 'pricing_template') {
            jQuery(this).parents('.sub-option-inner').find('.toggle-category').fadeIn();
        } else {
            jQuery(this).parents('.sub-option-inner').find('.toggle-category').fadeOut();
        }
    });

	jQuery('.pro-feature-title').click(function(){
        jQuery('.feature-img').slideToggle();
    });
});