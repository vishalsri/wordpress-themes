<?php
  /* for featured image  */  
  add_theme_support( 'post-thumbnails' );
	/* add_action( 'init', 'create_post_type' );
function create_post_type() {
  register_post_type( 'wfparallax_services',
    array(
      'labels' => array(
        'name' => __( 'Services' ),
        'singular_name' => __( 'Services' )
      ),
      'public' => true,
      'has_archive' => true,
	  'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'comments')
    )
  );
}
add_action( 'init', 'create_comment_post_type' );
function create_comment_post_type() {
  register_post_type( 'wfparallax_comments',
    array(
      'labels' => array(
        'name' => __( 'Testimonial' ),
        'singular_name' => __( 'Testimonial' )
      ),
      'public' => true,
      'has_archive' => true,
	  'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'comments')
    )
  );
} */
?>
<?php
//bxSlider Callback for do action
function WFParallax_bxslidercb(){
		global $post;
		$WFParallax_parallax = of_get_option('parallax_section');
		if(!empty($WFParallax_parallax)) :
			$WFParallax_parallax_first_page_array = array_slice($WFParallax_parallax, 0, 1);
			$WFParallax_parallax_first_page = $WFParallax_parallax_first_page_array[0]['page'];
		endif;
		$WFParallax_slider_category = of_get_option('slider_category');
		$WFParallax_slider_full_window = of_get_option('slider_full_window') ;
		$WFParallax_show_slider = of_get_option('show_slider') ;
		$WFParallax_show_pager = (!of_get_option('show_pager') || of_get_option('show_pager') == "yes") ? "true" : "false";
		$WFParallax_show_controls = (!of_get_option('show_controls') || of_get_option('show_controls') == "yes") ? "true" : "false";
		$WFParallax_auto_transition = (!of_get_option('auto_transition') || of_get_option('auto_transition') == "yes") ? "true" : "false";
		$WFParallax_slider_transition = (!of_get_option('slider_transition')) ? "fade" : of_get_option('slider_transition');
		$WFParallax_slider_speed = (!of_get_option('slider_speed')) ? "5000" : of_get_option('slider_speed');
		$WFParallax_slider_pause = (!of_get_option('slider_pause')) ? "5000" : of_get_option('slider_pause');
		$WFParallax_show_caption = of_get_option('show_caption') ;
		$WFParallax_enable_parallax = of_get_option('enable_parallax');
		?>

		<?php if( $WFParallax_show_slider == "yes" || empty($WFParallax_show_slider)) : ?>
		<section id="main-slider" class="full-screen-<?php echo $WFParallax_slider_full_window; ?>">
		
		<div class="overlay"></div>

		<?php if(!empty($WFParallax_parallax_first_page) && $WFParallax_enable_parallax == 1): ?>
		<div class="next-page"><a href="<?php echo esc_url( home_url( '/' ) ); ?>#section-<?php echo esc_attr($WFParallax_parallax_first_page); ?>"></a></div>
		<?php endif; ?>

 		<script type="text/javascript">
            jQuery(function($){
				$('#main-slider .bx-slider').bxSlider({
					adaptiveHeight: true,
					pager: <?php echo $WFParallax_show_pager; ?>,
					controls: <?php echo $WFParallax_show_controls; ?>,
					mode: '<?php echo $WFParallax_slider_transition; ?>',
					auto : <?php echo $WFParallax_auto_transition; ?>,
					pause: <?php echo $WFParallax_slider_pause; ?>,
					speed: <?php echo $WFParallax_slider_speed; ?>
				});

				<?php if($WFParallax_slider_full_window == "yes" && !empty($WFParallax_slider_category)) : ?>
				$(window).resize(function(){
					var winHeight = $(window).height();
					var headerHeight = $('#masthead').outerHeight();
					$('#main-slider .bx-viewport , #main-slider .slides').height(winHeight-headerHeight);
				}).resize();
				<?php endif; ?>
				
			});
        </script>
        <?php
		if( !empty($WFParallax_slider_category)) :

				$loop = new WP_Query(array(
						'cat' => $WFParallax_slider_category,
						'posts_per_page' => -1
					));
					if($loop->have_posts()) : ?>

					<div class="bx-slider">
					<?php
					while($loop->have_posts()) : $loop-> the_post(); 
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false ); 
					$image_url = "";
					if($WFParallax_slider_full_window == "yes") : 
						$image_url =  "style = 'background-image:url(".esc_url($image[0]).");'";
				    endif;
					?>
					<div class="slides" <?php echo $image_url; ?>>
					
					<?php if($WFParallax_slider_full_window == "no") : ?>		
						<img src="<?php echo esc_url($image[0]); ?>">
					<?php endif; ?>
								
						<?php if($WFParallax_show_caption == 'yes'): ?>
						<div class="slider-caption">
							<div class="mid-content">
								<h1 class="caption-title"><?php the_title();?></h1>
								<h2 class="caption-description"><?php the_content();?></h2>
							</div>
						</div>
						<?php endif; ?>
				
			        </div>
					<?php endwhile; ?>
					</div>
					<?php endif; ?>
			<?php else: ?>

            <div class="bx-slider">
				<div class="slides">
					<img src="<?php echo get_template_directory_uri(); ?>/images/demo/slider1.jpg" alt="slider1">
					<div class="slider-caption">
						<div class="mid-content">
							<h1 class="caption-title"><?php //_e('Welcome to WFParallax Parallax!','WFParallax'); ?></h1>
							<h2 class="caption-description">
							<p><?php //_e('A full featured parallax theme - and its absolutely free!','WFParallax'); ?></p>
							<p><a href="#"><?php //_e('Read More','WFParallax'); ?></a></p>
							</h2>
						</div>
					</div>
				</div>
						
				<div class="slides">
					<img src="<?php echo get_template_directory_uri(); ?>/images/demo/slider2.jpg" alt="slider2">
					<div class="slider-caption">
						<div class="ak-container">
							<h1 class="caption-title"><?php //_e('Amazing multi-purpose parallax theme','WFParallax'); ?></h1>
							<h2 class="caption-description">
							<p><?php //_e('Travel, corporate, small biz, portfolio, agencies, photography, health, creative - useful for anyone and everyone','WFParallax'); ?></p>
							<p><a href="#"><?php //_e('Read More','WFParallax'); ?></a></p>
							</h2>
							</div>
					</div>
				</div>
			</div>

			<?php  endif; ?>
		</section>
		<?php endif; ?>
<?php
}

//add_action('WFParallax_bxslider','WFParallax_bxslidercb', 10);

