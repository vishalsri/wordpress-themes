<?php 

if ( ! function_exists( 'wf_get_theme_version' ) ) :
	function wf_get_theme_version() {
		$theme_info = wp_get_theme();
		if ( is_child_theme() ) {
			$theme_info = wp_get_theme( $theme_info->parent_theme );
		}
		
		$theme_version = $theme_info->display( 'Version' );
		return $theme_version;
	}
endif;
function wfThemeSetup(){
	add_editor_style();
	add_theme_support('automatic-feed-links');
}
add_action('after_setup_theme', 'wfThemeSetup');

function wf_add_head_js_css() {
	global $theme_options;
	$theme_version = wf_get_theme_version();

	/* Register styles */
	wp_register_style( 'style', PARENT_URL. '/style.css', array(), $theme_version, 'all' );
	wp_register_style( 'bootstrap_css', PARENT_URL. '/css/bootstrap/css/bootstrap.min.css', array(), $theme_version, 'all' );
	wp_register_style( 'animate', PARENT_URL. '/css/animate.css', array(), $theme_version, 'all' );
	wp_register_style( 'hover', PARENT_URL. '/css/hover.css', array(), $theme_version, 'all' );
	
	wp_enqueue_style( 'bootstrap_css' );
	wp_enqueue_style( 'style' );
	wp_enqueue_style( 'animate' );
	wp_enqueue_style( 'hover' );


	/* Enqueue scripts */
	wp_enqueue_script( 'jquery' );	
	wp_enqueue_script( 'page-scroll', PARENT_URL. '/js/jquery.malihu.PageScroll2id.js', false, $theme_version, false );
	wp_enqueue_script( 'wow', PARENT_URL. '/js/wow.js', false, $theme_version, false );
	wp_enqueue_script( 'bootstrap', PARENT_URL. '/js/bootstrap.min.js', false, $theme_version, false );
	wp_enqueue_script( 'custom', PARENT_URL. '/js/custom.js', false, $theme_version, false );
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );	
}
add_action('wp_enqueue_scripts', 'wf_add_head_js_css');