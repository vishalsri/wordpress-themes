<?php
include_once(PARENT_DIR . '/includes/lib/menus.php');
include_once(PARENT_DIR . '/includes/lib/enque_script.php');
include_once(PARENT_DIR . '/includes/lib/custom_post.php');