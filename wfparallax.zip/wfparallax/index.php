<?php
/**
 * The main template file.
 *
 * This theme is purely for the purpose of testing theme options in Options Framework plugin.
 *
 * @package WordPress
 * @subpackage Options Framework Theme  
 */
	get_header(); 
 ?>
<?php get_template_part('sections/slider'); ?>
<?php 
	$sections = of_get_option('parallax_section');

	if(!empty($sections)):
		foreach ($sections as $section) :
			$page 					= get_post( $section['page'] ); 
			$overlay 					= $section['overlay'];
			$image 					= $section['image'];
			$layout 					= $section['layout'];
			$category 				= $section['category']; 
			$googlemapclass 	= $layout == "googlemap_template" ? " google-map" : "";
?>
<?php if(!empty($section['page'])): ?>
	<section class="content about <?php echo  $section['page']; ?> <?php echo esc_attr($googlemapclass)." ".esc_attr($layout);  ?>" id="<?php echo "section-".absint($page->ID); ?>" data speed="5" data-type="background" >
		<div class="container">
			<div class="row">
				<?php  
					$query = new WP_Query( 'page_id='.$section['page'] );
					while ( $query->have_posts() ) : $query->the_post();
				?>
				<?php 
					if($layout != "action_template" && $layout != "blank_template" && $layout != "googlemap_template"): ?>
						<div class="col-md-offset-1 col-md-10 col-sm-12 text-center">
							<h2 class="wow fadeInDown"><?php the_title(); ?></h2>
							<?php the_content(); ?>
						</div>
				<?php endif; ?>
				<?php 
					endwhile;    
				?>
				<?php 
					switch ($layout) {
						case 'default_template':
							$template = "layouts/default";
							break;

						case 'service_template':
							$template = "layouts/service";
							break;
							
						case 'pricing_template':
							$template = "layouts/pricing";
							break;	
						
						case 'contactus_template':
							$template = "layouts/contactus";
							break;
						
						case 'features_template':
							$template = "layouts/features";
							break;

						case 'team_template':
							$template = "layouts/team";
							break;

						case 'portfolio_template':
							$template = "layouts/portfolio";
							break;

						case 'testimonial_template':
							$template = "layouts/testimonial";
							break;

						case 'action_template':
							$template = "layouts/action";
							break;
							
						case 'about_template':
							$template = "layouts/about";
							break;

						case 'blank_template':
							$template = "layouts/blank";
							break;

						case 'googlemap_template':
							$template = "layouts/googlemap";
							break;

						case 'blog_template':
							$template = "layouts/blog";
							break;
						
						default:
							$template = "layouts/default";
							break;
					}
				?>
				<?php include(locate_template($template."-section.php"));?>
			</div>
		</div>
	</section>
<?php 
	endif;
	endforeach;
	endif;
?>
<?php get_footer(); ?>