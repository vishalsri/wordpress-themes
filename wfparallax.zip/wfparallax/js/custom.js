jQuery(document).ready(function() {
		(function($) {
			jQuery(window).load(function() {
				jQuery(".navbar a,a[href='#top'],a[rel='m_PageScroll2id']").mPageScroll2id({
					highlightSelector: ".navbar a"
				});
				jQuery("a[rel='next']").click(function(e) {
					e.preventDefault();
					var to = jQuery(this).parent().parent("section").next().attr("id");
					$.mPageScroll2id("scrollTo", to);
				});
			});
		})(jQuery);
	});

	jQuery(function() {
		jQuery('a[href*="#"]:not([href="#"])').click(function() {
			if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
				var target = jQuery(this.hash);
				target = target.length ? target : jQuery('[name=' + this.hash.slice(1) + ']');
				if (target.length) {
					jQuery('html, body').animate({
						scrollTop: target.offset().top
					}, 1000);
					return false;
				}
			}
		});
	});
 new WOW().init();
  jQuery(document).ready(function() {
            //Check to see if the window is top if not then display button
            jQuery(window).scroll(function() {
                if (jQuery(this).scrollTop() > 100) {
                    jQuery('.scrollToTop').fadeIn();
                } else {
                    jQuery('.scrollToTop').fadeOut();
                }
            });
            //Click event to scroll to top
            jQuery('.scrollToTop').click(function() {
                jQuery('html, body').animate({
                    scrollTop: 0
                }, 800);
                return false;
            });
        });