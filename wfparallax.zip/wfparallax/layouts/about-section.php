<?php
/**
 * The template for displaying all Parallax Templates.
 *
 * @package wfparallax
 */
?>
<!-------------------------------About Section Start------------------------------->


			<?php 
		$args = array(
			'cat' => $category,
			'posts_per_page' => -1
			);
		$query = new WP_Query($args);
		if($query->have_posts()): ?>
		<?php 
			while($query->have_posts()): $query->the_post();
		?>
			<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center">
				<?php if(has_post_thumbnail()) : 
			$image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'team-thumbnail');
			?>
				<img src="<?php echo esc_url($image[0]); ?>" alt="side" class="img-responisive center-block" />
				<h3><?php the_title(); ?></h3>
				<?php the_content(); ?>
			</div>
			<?php
			endif;
			endwhile;
			wp_reset_postdata(); ?>
<?php
		endif;
		?>


	<!-------------------------------About Section End------------------------------->