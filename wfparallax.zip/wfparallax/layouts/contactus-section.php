  <!------------------------------- Section Start------------------------------>
<?php   global $theme_options; ?>
   <?php  
            $query = new WP_Query( 'page_id='.$section['page'] );
            while ( $query->have_posts() ) : $query->the_post();
        ?>
            <div class="row   ">
                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <form method="post" name "contact-form">
                        <div class="form wow fadeInLeft">
						<?php echo do_shortcode(empty($theme_options[form])? "lorem ipsum donor ituse": $theme_options[form]);  ?>
						
                        </div>
                     <!--   <div class="form-1 wow fadeInLeft">
                            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                                <div class="form-group">
                                    <textarea id="message" class="form-control" rows="5" required="required" placeholder="Message*"></textarea>
                                </div>

                                <div class="form-group">
                                    <button class="btn btn-primary" required="required" name="submit" type="submit">Send Message</button>
                                </div>
                            </div>
                        </div>-->
                    </form>
                </div>

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12 ">
                    <div class="box1 icon-box-address box-content1 wow fadeInRight">
                        <i class="b-icon1 fa fa fa-map-marker"></i>
                        <span class="box-title1"><?php echo empty($theme_options[address])? "lorem ipsum donor ituse": $theme_options[address]; ?></span>
                        <div class="box-content1"></div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <div class="box1 icon-box-address box-content1 wow fadeInRight">
                        <i class="b-icon1 fa fa fa-phone"></i>
                        <span class="box-title1"><?php echo empty($theme_options[phone])? "061-256-2583": $theme_options[phone]; ?></span>
                        <div class="box-content1"></div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <div class="box1 icon-box-address box-content1 wow fadeInRight">
                        <i class="b-icon1 fa fa fa-envelope-o"></i>
                        <span class="box-title1"><?php echo empty($theme_options[email])? "contact@lorem.com": $theme_options[email]; ?></span>
                        <div class="box-content1"></div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <div class="box1 icon-box-address box-content1 wow fadeInRight">
                        <i class="b-icon1 fa fa fa-globe"></i>
                        <span class="box-title1"><?php echo empty($theme_options[web_address])? "support.loremipsum.com": $theme_options[web_address]; ?></span>
                        <div class="box-content1"></div>
                    </div>
                </div>

            </div>
			<?php 
						endwhile;    
						wp_reset_postdata();
						?>

    <!------------------------------- Section End------------------------------->