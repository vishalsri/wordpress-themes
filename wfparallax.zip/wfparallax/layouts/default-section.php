<?php
/**
 * The template for displaying all Parallax Templates.
 *
 * @package accesspress_parallax
 */
?>
	<div class="content-area">

	</div><!-- #primary -->



