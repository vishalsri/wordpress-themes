<?php 
		$args = array(
			'cat' => $category,
			'posts_per_page' => -1
			);
		$count_service = 0;
		$query = new WP_Query($args);
		?>
<?php	
	if($query->have_posts()):
			$i = 0;
            while ($query->have_posts()): $query->the_post();
            $i = $i + 0.25;
			$count_service++;
			$service_class = ($count_service % 2 == 0) ? "even wow fadeInRight" : "odd wow fadeInLeft";
		?>
                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12 <?php echo esc_attr($service_class); ?>" data-wow-delay="<?php echo $i; ?>s" >
                    <div class="box service-image">
						<i class=" true fa fa fa-arrow-right hvr-bob"></i>                       
                       <a href="#"> <span><?php the_title(); ?>–</span></a><?php echo get_the_content(); ?> 
				   </div>
                </div>                    
						<?php 
		if($count_service % 2 == 0): ?>
			<div class="clearfix"></div>
		<?php endif;
		?>

		<?php
			endwhile;
			wp_reset_postdata();
		endif;
	?>
						
	

                    <!--    <li>
                            <a href="#">
                                <span>Ability to oversubscribe – </span>computing resources within allocated pool
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Service Level Agreement – </span>guaranteed uptime and availability
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Enterprise Grade Compute Resources– </span> on Evolve IP’s Enterprise-class Cluster
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Best-in-Class virtualization technology – </span>from VMware and EMC
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>True Customer Isolation– </span>with Private VLAN
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>High Availability – </span>Hardware Failover Built-in
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                    <ul>
                        <li>
                            <a href="#">
                                <span>Guaranteed Resource Reservation – </span>Compute resources 100% allocated
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Ability to oversubscribe – </span>computing resources within allocated pool
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Service Level Agreement – </span>guaranteed uptime and availability
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Enterprise Grade Compute Resources– </span> on Evolve IP’s Enterprise-class Cluster
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>Best-in-Class virtualization technology – </span>from VMware and EMC
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>True Customer Isolation– </span>with Private VLAN
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span>High Availability – </span>Hardware Failover Built-in
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>-->

    <!------------------------------- Section End------------------------------->