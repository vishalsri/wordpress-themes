<?php
/**
 * The template for displaying all Parallax Templates.
 *
 * @package wfparallax
 */
?>
<?php $externallink= rwmb_meta('wfparallax_external_link',array("type"=>"text")); ?>
<?php $price= rwmb_meta('wfparallax_price',array("type"=>"text")); ?>
<?php //echo '<pre>'; print_r($price); echo '</pre>'; die(__FILE__ . " On  ". __LINE__); ?>
    <!------------------------------- Section Start------------------------------->

     <section class="pricing-table">
        <div class="container">
            <div class="row">
                <div class="container">
                    <div class="row">					
							<?php 
								$args = array(
								'cat' => $category,
								'posts_per_page' => -1
								);
							$query = new WP_Query($args);
								if($query->have_posts()): ?>
							<?php 
								while($query->have_posts()): $query->the_post();
									$externallink= rwmb_meta('wfparallax_external_link',array("type"=>"text")); 
									$price= rwmb_meta('wfparallax_price',array("type"=>"text")); 
							?>
                        <div class="col-lg-5ths col-md-5ths col-sm-4 col-xs-12 facilities text-center">
                            <!-- PRICE ITEM -->
                            <div class="panel price panel-grey">
                                <div class="panel-heading arrow_box text-center">
                                    <h3><?php the_title(); ?></h3>
                                </div>
                                <div class="panel-body text-center">
                                    <p class="lead" style="font-size:40px"><strong><?php echo $price; ?></strong>
                                    </p>
                                </div>
								<div class="price text-center">
                                <?php the_content(); ?>
								</div>
                                <div class="panel-footer">
                                    <a class="btn btn-lg btn-block btn-primary" href="<?php echo $externallink; ?>">BUY NOW!</a>
                                </div>
                            </div>
                            <!-- /PRICE ITEM -->
                        </div>
						<?php
							endwhile;
							wp_reset_postdata(); ?>
						<?php
							endif;
						?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!------------------------------- Section End------------------------------->