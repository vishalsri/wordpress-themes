<?php 
		$args = array(
			'cat' => $category,
			'posts_per_page' => -1
			);
		$count_service = 0;
		$query = new WP_Query($args);
		if($query->have_posts()):
			$i = 0;
            while ($query->have_posts()): $query->the_post();
            $i = $i + 0.25;
			$count_service++;
			$service_class = ($count_service % 2 == 0) ? "even wow fadeInRight" : "odd wow fadeInLeft";
		?>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 wow fadeInLeft <?php echo esc_attr($service_class); ?>" data-wow-delay="<?php echo $i; ?>s" >
                    <div class="box service-image">
					<?php if(has_post_thumbnail()) : 
				$image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'full'); ?>
					<img src="<?php echo esc_url($image[0]); ?>" alt="<?php the_title(); ?>" class="img-responsive">
				<?php else: ?>
					<i class="b-icon true fa fa fa-align-justify hvr-bob"></i>
				<?php endif; ?>                        
                        <span class="box-title">
								<?php the_title(); ?>
							</span>
                        <div class="box-content">
                            <p>
                               <?php the_content(); ?>
                            </p>
                        </div>
                    </div>
                </div>
				
						<?php 
		if($count_service % 2 == 0): ?>
			<div class="clearfix"></div>
		<?php endif;
		?>

		<?php
			endwhile;
			wp_reset_postdata();
		endif;
	?>