<?php global $theme_options; ?>
<section id="home" class="top-buffer slider" data speed="10" data-type="background">
	<div class="container-fluid no-padding">
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<img src="<?php echo $theme_options['background']; ?><?php bloginfo( 'template_url' ); ?>/images/slider.jpg" alt="slider" class="img-responisive center-block" />
							<h2 class="wow fadeInDown"><?php echo empty($theme_options[slider_heading])? "Lorem": $theme_options[slider_heading]; ?><!--<span> Ipsum</span>--> </h2>
							<p><?php echo empty($theme_options[slider_details])? "Lorem Ipsum is simply dummy text of the printing and typesetting industry": $theme_options[slider_details]; ?>
						   </p>
							<a href="#" class="more wow fadeInLeft"><?php echo empty($theme_options[slider_link1])? "Our Services": $theme_options[slider_link1]; ?></a>
							<a href="#" class="more1 wow fadeInRight"><?php echo empty($theme_options[slider_link2])? "Learn More": $theme_options[slider_link2]; ?></a>
						</div>
					</div>
					<!-- Left and right controls -->
					<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>