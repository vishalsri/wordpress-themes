<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package wfspa
 * @since wfspa 1.0
 */
get_header(); ?>
<section id="404">
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 top-buffer"></div>
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 top-buffer text-center">
					<div class="article wow fadeInDown ">
						<div class="row top-buffer">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<h1 class="page-title"><?php _e( 'Oops! That page can&rsquo;t be found.', 'wfspa' ); ?></h1>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 page-content">
								<p><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'wfspa' ); ?></p>
							</div><!-- .page-content -->
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 top-buffer"></div>
			</div>
		</div>
	</section>
	<?php get_footer(); ?>