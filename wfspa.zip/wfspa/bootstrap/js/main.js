$(document).ready(function() {
	$("#userlogin").click(function() {
		var UserName =$(".UserName").val();
		var Password =$(".Password").val();

		if(UserName == ""){
			$(".UserName").css("border","1px solid red");
		return false;
		}else{
			$(".UserName").css("border","1px solid");}
		if(Password == ""){
			$(".Password").css("border","1px solid red");
		return false;
		}else{
			$(".Password").css("border","1px solid");}
		return true;
 	});
});
