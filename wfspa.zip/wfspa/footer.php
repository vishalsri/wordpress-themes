<!-- footer start -->
<?php  global $theme_options; ?>
	<footer id="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="social-icon-footer">
						<a href="<?php echo empty($theme_options['facebook'])? "#": $theme_options['facebook']; ?>">
							<i class="fa fa-facebook hvr-bob"></i>
						</a>
						<a href="<?php echo empty($theme_options['twitter'])? "#": $theme_options['twitter']; ?>">
							<i class="fa fa-twitter hvr-bob"></i> 
						</a>
						<a href="<?php echo empty($theme_options['googlePlus'])? "#": $theme_options['googlePlus']; ?>">
							<i class="fa fa-google hvr-bob"></i>
						</a>
						<a href="<?php echo empty($theme_options['linkedin'])? "#": $theme_options['linkedin']; ?>">
							<i class="fa fa-linkedin hvr-bob"></i>
						</a>
						<p><?php echo empty($theme_options['footer-copyright'])? "Copyright © 2016": $theme_options['footer-copyright']; ?></p>
					</div>
				</div>
				<a href="javascript:void();" class="scrollToTop wow fadeInUp"><i class="fa fa-angle-up"></i></a>	
			</div>
		</div>
	</footer>	
	<!-- footer end -->
	<?php wp_footer(); ?>
</body>
</html>