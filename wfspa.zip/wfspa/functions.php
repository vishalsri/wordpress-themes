  <?php
/**
 * Spa functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package wfspa
 * @subpackage wfspa
 * @since wfspa 1.0
 */
if ( ! function_exists( 'spa_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own spa_setup() function to override in a child theme.
 *
 * @since wfspa 1.0
 */
function spa_setup() {
	/*
	 * Make theme available for translation.
	 * If you're building a theme based on wfspa, use a find and replace
	 * to change 'wfspa' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'wfspa' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since wfspa 1.2
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );
	add_image_size( 'list-post-thumbnail', 500, 500, true );
	add_image_size( 'archive-list-post-thumbnail', 250, 250, true );

	// This theme uses wp_nav_menu() in two locations.
	/* register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'wfspa' ),
		'social'  => __( 'Social Links Menu', 'wfspa' ),
	) ); */

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'widgets',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'status',
		'audio',
		'chat',
	) );
		/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	//add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // spa_setup
add_action( 'after_setup_theme', 'spa_setup' );
function register_my_menu() {
	register_nav_menu('top-menu',__( 'Menu' ,'wfspa'));  
}
add_action( 'init', 'register_my_menu' );
if ( ! isset( $content_width ) ) $content_width = 900;
/**
 * Filter the except length to 20 characters.
 *
 * @param int $length Excerpt length.
 * @return int (Maybe) modified excerpt length.
 */
function wpdocs_custom_excerpt_length( $length ) {
    return 12;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/inc/options/ReduxCore/framework.php' ) ) {

	require_once( dirname( __FILE__ ) . '/inc/options/ReduxCore/framework.php' );

}

if ( !isset( $redux_demo ) && file_exists( dirname( __FILE__ ) . '/inc/options/sample/sample-config.php' ) ) {

	require_once( dirname( __FILE__ ) . '/inc/options/sample/sample-config.php' );

}
/**custom post type files**/
require_once( dirname( __FILE__ ) . '/inc/custom/custom_post_type.php' );
/**custom meta box files**/
require_once( dirname( __FILE__ ) . '/inc/custom/custom_meta_box.php' );
/**scripts of the theme**/
require_once( dirname( __FILE__ ) . '/inc/scripts/scripts.php' );
/**register widgets of the theme**/
require_once( dirname( __FILE__ ) . '/inc/widgets/register_widgets.php' );

	

?>
