<?php
/**
 * The template for displaying the header
 *
 * Displays all of the header element 
 *
 * @package wfspa
 */
 global $theme_options;
?><!DOCTYPE html>
<html <?php language_attributes(); ?> >
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<style>
			/* Custom css*/

			<?php if(!empty($theme_options['body-color'])) { ?>
				body{
				background-color:<?php echo $theme_options['body-color']; ?> !important;
				}
			<?php }  ?>
			<?php if(!empty($theme_options['top_menu_color'])) { ?>
				.header-top{
				background-color:<?php echo $theme_options['top_menu_color']; ?> !important;
				}
				.header-menu{
				background-color:<?php echo $theme_options['nav-color']; ?> !important;
				border-color:<?php echo $theme_options['nav-color']; ?> !important;
				}
			<?php } ?>
			<?php if(!empty($theme_options['about-section'])) { ?>
						.about {
						background:<?php echo $theme_options['about-section']; ?> none repeat scroll 0 0!important;
			<?php } ?>	
			<?php if(!empty($theme_options['info-section'])) { ?>
						.information {
						background-color:<?php echo $theme_options['info-section']; ?>!important;
						.product {
						background-color:<?php echo $theme_options['info-section']; ?>!important;
			<?php } ?>		
			<?php if(!empty($theme_options['footer'])) { ?>
						#footer {
						background:<?php echo $theme_options['footer']; ?> none repeat scroll 0 0!important;
			<?php } ?>	
			<?php if (!empty($theme_options['custom-css'])) { ?>
			<?php echo $theme_options['custom-css']; ?>
			<?php } ?>
	</style> 
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<!-- header start -->
	<header>
		<!-- header-top start -->
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 text-center">
						<div class="social-icon-top">
							<ul>
								<li><a href="<?php echo empty($theme_options['facebook'])? "#": $theme_options['facebook']; ?>"><i class="fa fa-facebook"></i></a></li>
								<li><a href="<?php echo empty($theme_options['twitter'])? "#": $theme_options['twitter']; ?>"><i class="fa fa-twitter"></i></a></li>	
								<li><a href="<?php echo empty($theme_options['googlePlus'])? "#": $theme_options['googlePlus']; ?>"><i class="fa fa-google-plus"></i></a></li>
							</ul>		
						</div><!-- / social-icon-top end -->
					</div>
					<div class="col-lg-6 col-md-6col-sm-6 col-xs-12"></div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="top-mail">
							<ul>
								<li><a href="tel:<?php echo empty($theme_options['phone'])? "Phone:(123-456-7890)": $theme_options['phone']; ?>"><i class="fa fa-phone"></i> <?php echo empty($theme_options['phone'])? "Phone:(123-456-7890)": $theme_options['phone']; ?></a></li>
								<li><a href="mailto:<?php echo empty($theme_options['footer-email'])? "lorem@gmail.com": $theme_options['footer-email']; ?>"><i class="fa fa-envelope"></i><?php echo empty($theme_options['footer-email'])? "lorem@gmail.com": $theme_options['footer-email']; ?></a></li>
							</ul>
						</div><!-- / top-mail end -->
					</div>
				</div>
			</div>
		</div>
		<!-- header-top end -->
		
		<!-- header-menu start -->
		<div class="header-menu">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="top-menu">
							<nav class="navbar navbar-inverse">
							  <div class="container-fluid">
								<div class="navbar-header">
								  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span> 
								  </button>
								  <div class="logo">
									<?php if(!empty($theme_options['logo']['url'])){ ?>
									<a href="<?php echo esc_url( home_url() ); ?>"><img src="<?php echo $theme_options['logo']['url']; ?>" alt="logo" class="img-responsive center-block" /></a>
									<?php } ?>
									<?php if(empty($theme_options['logo']['url'])){ ?>
									<h2><a href="<?php echo esc_url( home_url() ); ?>"><?php _e('LOGO','wfspa');?></a></h2>
									<?php } ?>
								</div>
								</div>
								<div class="collapse navbar-collapse text-center" id="myNavbar">
								 <?php wp_nav_menu( array( 'theme_location' 	=> 'top-menu', 
																				'items_wrap'      	=> '<ul class="nav navbar-nav navbar-right">%3$s</ul>',
																				'menu_class' 			=> 'nav navbar-nav ' ) ); ?>
								</div>
							  </div>
							</nav><!-- / navbar end -->
						</div><!-- / top-menu end -->
					</div>
				</div>
			</div>
		</div>
		<!-- header-menu end -->
	</header>
	<!-- header end -->
