<?php 
function add_info_metaboxes()
{
    add_meta_box("wf_info_icon", "Add Fontawesome icon class", "wf_info_icon", "info", "side", "default", null);
}

add_action( 'add_meta_boxes', 'add_info_metaboxes' );
function wf_info_icon()
{
	global $post;
   echo '<input type="hidden" name="infometa_noncename" id="infometa_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	
	$icon = get_post_meta($post->ID, '_icon', true);
	
	// Echo out the field
	echo '<input type="text" name="_icon" value="' . $icon  . '" class="" />';
	echo '<br><span>Add fontawesome class like <em>fa fa-eye</em>.</span>';

}
// Save the Metabox Data

function wf_save_info_meta($post_id, $post) {
	
	// verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( !wp_verify_nonce( $_POST['infometa_noncename'], plugin_basename(__FILE__) )) {
	return $post->ID;
	}

	// Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

	// OK, we're authenticated: we need to find and save the data
	// We'll put it into an array to make it easier to loop though.
	
	$info_meta['_icon'] = $_POST['_icon'];
	
	// Add values of $info_meta as custom fields
	
	foreach ($info_meta as $key => $value) { // Cycle through the $info_meta array!
		if( $post->post_type == 'revision' ) return; // Don't store custom data twice
		$value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
		if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
			update_post_meta($post->ID, $key, $value);
		} else { // If the custom field doesn't have a value
			add_post_meta($post->ID, $key, $value);
		}
		if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
	}

}

add_action('save_post', 'wf_save_info_meta', 1, 2); // save the custom fields
