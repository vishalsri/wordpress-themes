<?php
/***Custom post type for information***/
function wf_info_posttype() {
	register_post_type( 'info',
				array( 
				'label' => __('Information','wfspa'),
				'public' => true, 
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'menu_position' => 5.1,
				'menu_icon' => 'dashicons-info',
				'register_meta_box_cb' => 'add_info_metaboxes',
				'rewrite' => array(
					'slug' => 'info',
					'with_front' => FALSE,
				),
				'supports' => array(
						'title',
						'thumbnail',
						'editor',
						),
						'taxonomies'		  => array('topics', 'category' ,'tags'),
					) 
				);
}
add_action('init', 'wf_info_posttype');
/***Custom post type for team***/
function wf_team_posttype() {
	register_post_type( 'team',
				array( 
				'label' => __('Team','wfspa'),
				'public' => true, 
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'menu_position' => 5.1,
				'menu_icon' => 'dashicons-groups',
				'rewrite' => array(
					'slug' => 'team',
					'with_front' => FALSE,
				),
				'supports' => array(
						'title',
						'thumbnail',
						'editor',
						'custom-fields' ,
						),
						'taxonomies'		  => array('topics', 'category' ,'tags'),
					) 
				);
}
add_action('init', 'wf_team_posttype');
/***Custom post type for gallery***/
function wf_gallery_posttype() {
	register_post_type( 'gallery',
				array( 
				'label' => __('Gallery','wfspa'),
				'public' => true, 
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'menu_position' => 5.1,
				'menu_icon' => 'dashicons-format-gallery',
				'rewrite' => array(
					'slug' => 'gallery',
					'with_front' => FALSE,
				),
				'supports' => array(
						'title',
						'thumbnail',
						'editor',
						'custom-fields' ,
						),
						'taxonomies'		  => array('topics', 'category' ,'tags'),
					) 
				);
}
add_action('init', 'wf_gallery_posttype');