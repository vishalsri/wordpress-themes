<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 * You also should read the changelog to know what has been changed before updating.
 *
 * For more information, please visit:
 * @link http://www.deluxeblogtips.com/meta-box/
 */


add_filter( 'rwmb_meta_boxes', 'wf_fuark2016_register_meta_boxes' );

/**
 * Register meta boxes
 *
 * @return void
 */
function wf_fuark2016_register_meta_boxes( $meta_boxes )
{
	/**
	 * Prefix of meta keys (optional)
	 * Use underscore (_) at the beginning to make keys hidden
	 * Alt.: You also can make prefix empty to disable it
	 */
	// Better has an underscore as last sign
	$prefix = 'wf_fuark2016_';
	
	
	$meta_boxes[] = array(
		'title' => __( 'Post Embed Code ', 'fuark2016' ),
		'pages' => array( 'post' ),
		'context'  => 'normal',
		'fields' => array(
			// CHECKBOX
			array(
				'name'  => __( 'Youtube Embed Code', 'fuark2016' ),
				'id'    => "{$prefix}youtube_code",
				'desc'  => __( 'Please add post youtube video embed code.', 'fuark2016' ),
				'type' => 'textarea',
				'cols' => 20,
				'rows' => 10
			),		
			array(
				'name'  => __( 'Sponser Code On/off', 'fuark2016' ),
				'id'    => "{$prefix}sponser",
				'desc'  => __( 'Please select sponser.', 'fuark2016' ),				
				'type'     => 'radio',
				// Array of 'value' => 'Label' pairs for select box
				'options'  => array(
					'on' => __( 'on', 'fuark2016' ),
					'off' => __( 'off', 'fuark2016' )
				),
			),		
			array(
				'name'  => __( 'Hide Ad sense', 'fuark2016' ),
				'id'    => "{$prefix}hideads",
				'desc'  => __( 'Select to hide ads for current post.', 'fuark2016' ),				
				'type'     => 'radio',
				// Array of 'value' => 'Label' pairs for select box
				'options'  => array(
					'on' => __( 'on', 'fuark2016' ),
					'off' => __( 'off', 'fuark2016' )
				),
			),		
			array(
				'name'  => __( 'Show Top Adsens', 'fuark2016' ),
				'id'    => "{$prefix}show_top_ads",
				'desc'  => __( 'Select to hide ads for current post.', 'fuark2016' ),				
				'type'     => 'radio',
				// Array of 'value' => 'Label' pairs for select box
				'options'  => array(
					'on' => __( 'on', 'fuark2016' ),
					'off' => __( 'off', 'fuark2016' )
				),
			),		
		),
	);
	
	$meta_boxes[] = array(
		'title' => __( 'Sponser Code 2', 'fuark2016' ),
		'pages' => array( 'post' ),
		'context'  => 'normal',
		'fields' => array(
			array(
				'name'  => __( 'Sponser Code 2 on/off', 'fuark2016' ),
				'id'    => "{$prefix}sponser_two",
				'desc'  => __( 'Select sponser code 2.', 'fuark2016' ),				
				'type'     => 'radio',
				// Array of 'value' => 'Label' pairs for select box
				'options'  => array(
					'on' => __( 'on', 'fuark2016' ),
					'off' => __( 'off', 'fuark2016' )
				),
			),	
		)
	);

	return $meta_boxes;
}


