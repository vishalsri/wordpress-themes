<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }
    // This is your option name where all the Redux data is stored.
    $opt_name = "theme_options";
    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );
    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */
    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();
        global $wp_filesystem;
        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }
    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    if ( is_dir( $sample_patterns_path ) ) {
        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();
            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {
                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }
    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */
    $theme = wp_get_theme(); // For use with some settings. Not necessary.
    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Spa Options', 'wfspa' ),
        'page_title'           => __( 'Spa Options', 'wfspa' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.
        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );
    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    /* $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'wfspa' ),
    );
    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'wfspa' ),
    );
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'wfspa' ),
    ); */
  
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/wapfluid',
        'title' => 'Like us on Facebook',
        'icon'  => 'el el-facebook'
    );
    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
       /*  $args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'wfspa' ), $v ); */
    } else {
      /*   $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'wfspa' ); */
    }
    // Add content after the form.
    /* $args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'wfspa' ); */
    Redux::setArgs( $opt_name, $args );
    /*
     * ---> END ARGUMENTS
     */
    /*
     * ---> START HELP TABS
     */
    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'wfspa' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'wfspa' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'wfspa' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'wfspa' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );
    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'wfspa' );
    Redux::setHelpSidebar( $opt_name, $content );
	$pages = get_all_page_ids(); 
	foreach($pages as $padeId){
		$pageList[$padeId]=get_the_title($padeId);
	}
    /*
     * <--- END HELP TABS
     */
    /*
     *
     * ---> START SECTIONS
     *
     */
    /*
        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for
     */
    /***OPTIONS FOR LOGO TEXT-LOGO FAVICON OF THE SITE***/
    Redux::setSection( $opt_name, array(
        'title'            => __( 'General', 'wfspa' ),
        'id'               => 'general',
        'desc'             => __( 'These are really basic settings!', 'wfspa' ),
        'customizer_width' => '400px',
        'icon'             => 'el el-home'
    ) );
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Home', 'wfspa' ),
		'id'               => 'basic-checkbox',
		'subsection'       => true,
		'customizer_width' => '450px',
		'desc'             => false,
		'fields'           => array(
			array(
				'id' => 'logo',
				'type' => 'radio',
				'title' => __( 'Logo', 'wfspa' ),
				'options' => array(
					'text'=>'Text Logo',
					'image'=>'Upload Images'
				),
				'default' => 'text'	
			),
			array(
				'id'       => 'logo_text',
				'type'     => 'text',
				'url'      => false,
				'title'    => __( 'text Logo', 'wfspa' ),
				'compiler' => 'true',
				'desc'     => __( 'text Logo of website.', 'wfspa' ),
				'subtitle' => __( 'write text for logo of website ', 'wfspa' )
			),
			array(
				'id'       => 'logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Regular Logo', 'wfspa' ),
				'compiler' => 'true',
				'desc'     => __( 'Logo of website.', 'wfspa' ),
				'subtitle' => __( 'Upload logo of website using uploder', 'wfspa' )
			),
			array(
				'id'       => 'mobile-logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Mobile Logo', 'wfspa' ),
				'compiler' => 'true',
				'desc'     => __( 'Mobile Logo of website.', 'wfspa' ),
				'subtitle' => __( 'Upload mobile version logo of website using uploder', 'wfspa' )
			),
			array(
				'id'       => 'favicon',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Favicon Icon', 'wfspa' ),
				'compiler' => 'true',
				'desc'     => __( 'Favicon of website.', 'wfspa' ),
				'subtitle' => __( 'Upload favicon of website using uploder', 'wfspa' )
			),
		)
	) );
	/***OPTIONS FOR ADD SLIDER ON THE HEADER SECTION***/
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Slider', 'wfspa' ),
		'id'               => 'slider',
		'subsection'       => true,
		'customizer_width' => '450px',
		'desc'             => false,
		'fields'           => array(
				array(
				'id'=>'header-slides', 
				'type' => 'slides',
				'title' => __('Header Slides', 'redux-framework-demo'),
				'subtitle'=> __('Unlimited slides with drag and drop sortings.', 'redux-framework-demo'),
				'desc' => __('This field will store all slides values into a multidimensional array to use into a foreach loop.', 'redux-framework-demo')
				),
			)
	) );					
	/***OPTIONS FOR COPYRIGHT TEXT IN FOOTER SECTION***/
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Footer', 'wfspa' ), 
		'id'               => 'footer',
		'subsection'       => true,
		'customizer_width' => '450px',
		'desc'             => false,
		'fields'           => array(
			array(
				'id'          => 'footer-copyright',
				'type'        => 'textarea',
				'title'       => __( 'Footer', 'wfspa' ),
				'subtitle'    => __( 'Footer copyright text', 'wfspa' ),
				'desc'        => __( 'Add copyright text', 'wfspa' ),
				'placeholder' => 'COPYRIGHT 2015 . ALL RIGHTS RESERVED.',
			),
			array(
				'id'          => 'footer-email',
				'type'        => 'text',
				'title'       => __( 'Footer', 'wfspa' ),
				'subtitle'    => __( 'Footer email', 'wfspa' ),
				'desc'        => __( 'Add email', 'wfspa' ),
				'placeholder' => 'email.',
			),
		)
	) );
    /*** OPTIONS FOR CONTACT INFORMATIONS ***/
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Contacts', 'wfspa' ),
		'id'               => 'contacts',
		'customizer_width' => '500px',
		'icon'             => 'el el-map-marker',
	) );
	
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Contact Info', 'wfspa' ),
        'id'         => 'contact-info',
        'desc'       => __( 'Add contact details','wfspa'),
        'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'address-info',
                'type'     => 'editor',
                'title'    => __( 'Other Info', 'wfspa' ),
                'subtitle' => __( 'Provide other info here', 'wfspa' ),
                'default'  => '<dt class="indent-bot">8901 Marmora Road, Glasgow, D04 89GR.</dt>',
				'args'    => array(
                    'wpautop'       => true,
                    'media_buttons' => false,
                    'textarea_rows' => 5,
                )
            ),
			array(
				'id'=>'phone',
				'type' => 'text',
				'title' => __('Phone Number', 'cadieux'), 
				'placeholder' => __('Phone Number', 'cadieux'), 
				'subtitle' => __('Add phone number here.', 'cadieux'),
			),
			array(
				'id'          => 'email',
				'type'        => 'text',
				'title'       => __( 'Email', 'wfspa' ),
				'subtitle'    => __( 'email', 'wfspa' ),
				'desc'        => __( 'Add email', 'wfspa' ),
				'placeholder' => 'email.',
			),
		)
    ) );
	/***OPTIONS FOR SOCIAL LINKS OF THE SITE ***/
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Social Links', 'wfspa' ),
        'id'         => 'social-links',
        'desc'       => __( 'Add all socials links here','wfspa'),
        'subsection' => true,
        'fields'     => array(
           	array(
				'id'=>'facebook',
				'type' => 'text',
				'title' => __('Facebook URL', 'cadieux'), 
				'placeholder' => __('Facebook URL', 'cadieux'), 
				'subtitle' => __('Add facebook url here.', 'cadieux'),
			),
			array(
				'id'=>'twitter',
				'type' => 'text',
				'title' => __('Twitter URL', 'cadieux'), 
				'placeholder' => __('Twitter URL', 'cadieux'), 
				'subtitle' => __('Add Twitter url here.', 'cadieux'),
			),
			
			 array(
				'id'=>'googlePlus',
				'type' => 'text',
				'title' => __('Google plus URL', 'cadieux'), 
				'placeholder' => __('Google plus URL', 'cadieux'), 
				'subtitle' => __('Add Google plus url here.', 'cadieux'),
			),
			array(
				'id'=>'pinterest',
				'type' => 'text',
				'title' => __('Pinterest URL', 'cadieux'), 
				'placeholder' => __('Pinterest URL', 'cadieux'), 
				'subtitle' => __('Add pinterest url here.', 'cadieux'),
			), 
			array(
				'id'=>'instagram',
				'type' => 'text',
				'title' => __('Instagram URL', 'cadieux'), 
				'placeholder' => __('Instagram URL', 'cadieux'), 
				'subtitle' => __('Add instagram url here.', 'cadieux'),
			),
			array(
				'id'=>'youTube',
				'type' => 'text',
				'title' => __('Youtube URL', 'cadieux'), 
				'placeholder' => __('Youtube URL', 'cadieux'), 
				'subtitle' => __('Add Youtube url here.', 'cadieux'),
			),
			array(
				'id'=>'linkedin',
				'type' => 'text',
				'title' => __('LINKEDIN URL', 'cadieux'), 
				'placeholder' => __('linkedin URL', 'cadieux'), 
				'subtitle' => __('Add linkedin url here.', 'cadieux'),
			),
			array(
				'id'=>'skype',
				'type' => 'text',
				'title' => __('Skype URL', 'cadieux'), 
				'placeholder' => __('Skype URL', 'cadieux'), 
				'subtitle' => __('Add Skype url here.', 'cadieux'),
			),
		 )
    ) );
	 /***OPTIONS FOR COLORS***/
    Redux::setSection( $opt_name, array(
        'title'            => __( 'Colors', 'wfspa' ),
        'id'               => 'colors',
        'customizer_width' => '500px',
        'icon'             => 'el el-puzzle',
    ) );
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Website Color', 'wfspa' ),
        'id'         => 'website-colors',
        'desc'       => __( 'Add all socials links here','wfspa'),
        'subsection' => true,
        'fields'     => array(
			
			array(
				'id'       => 'body-color',
				'type'     => 'color',
				'title'    => __( 'body Color', 'wfspa' ),
				'subtitle' => __( 'Pick a body color for the theme (default: #fff).', 'wfspa' ),
				'default'  => '#fff',
			),
			array(
				'id'       => 'top_menu_color',
				'type'     => 'color',
				'title'    => __( 'Top Nav Color ', 'wfspa' ),
				'subtitle' => __( 'Pick a top navigation color for the theme (default: #861347).', 'wfspa' ),
				'default'  => '#861347',
			),
			array(
				'id'       => 'nav-color',
				'type'     => 'color',
				'title'    => __( 'Navbar Color', 'wfspa' ),
				'subtitle' => __( 'Pick a  Navbar color for the theme (default: #fff).', 'wfspa' ),
				'default'  => '#fff',
			),
			array(
				'id'       => 'about-section',
				'type'     => 'color',
				'title'    => __( 'About section Color', 'wfspa' ),
				'subtitle' => __( 'Pick a about section color for the theme (default: #f1f1f4).', 'wfspa' ),
				'default'  => '#f1f1f4',
			),
			array(
				'id'       => 'info-section',
				'type'     => 'color',
				'title'    => __( 'Info section Color', 'wfspa' ),
				'subtitle' => __( 'Pick a info section color for the theme (default: #B3195E).', 'wfspa' ),
				'default'  => '#B3195E',
			),
			array(
				'id'       => 'footer',
				'type'     => 'color',
				'title'    => __( 'Footer Color', 'wfspa' ),
				'subtitle' => __( 'Pick a footer color for the theme (default: #861347).', 'wfspa' ),
				'default'  => '#861347',
			),
		)
    ) );
	/***OPTIONS FOR HEADING OF INFORMATION***/
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Info heading', 'wfspa' ),
		'id'               => 'info',
		'customizer_width' => '500px',
		'icon'             => 'el el-info-circle',
	) );
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Info heading', 'wfspa' ),
        'id'         => 'info-heading',
        'desc'       => __( 'Add info heading','wfspa'),
        'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'info-heading',
                'type'     => 'editor',
                'title'    => __( 'Info heading', 'wfspa' ),
                'subtitle' => __( 'Provide info heading here', 'wfspa' ),
				'args'    => array(
                    'wpautop'       => true,
                    'media_buttons' => false,
                    'textarea_rows' => 5,
                )
            ),
		)
    ) );
		/***OPTIONS FOR HEADING AND CONTENT OF PRODUCT SECTION***/
	Redux::setSection( $opt_name, array(
		'title'            => __( 'Product heading', 'wfspa' ),
		'id'               => 'pro',
		'customizer_width' => '500px',
		'icon'             => 'el el-shopping-cart-sign',
	) );
	
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Product heading', 'wfspa' ),
        'id'         => 'product-heading',
        'desc'       => __( 'Add Product heading','wfspa'),
        'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'pro-heading',
                'type'     => 'editor',
                'title'    => __( 'product heading', 'wfspa' ),
                'subtitle' => __( 'Provide product heading here', 'wfspa' ),
				'args'    => array(
                    'wpautop'       => true,
                    'media_buttons' => false,
                    'textarea_rows' => 5,
                )
            ),
			array(
                'id'       => 'pro-content',
                'type'     => 'editor',
                'title'    => __( 'product content', 'wfspa' ),
                'subtitle' => __( 'Provide product content here', 'wfspa' ),
				'args'    => array(
                    'wpautop'       => true,
                    'media_buttons' => false,
                    'textarea_rows' => 5,
                )
            ),
		)
    ) );
	/***OPTIONS FOR HEADING AND CONTENT OF ABOUT SECTION***/
	Redux::setSection( $opt_name, array(
        'title'            => __( 'About', 'wfspa' ),
        'id'               => 'aboutsite',
        'customizer_width' => '500px',
        'icon'             => 'el el-info-circle',
    ) );	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'About section', 'wfspa' ), 
		'id'               => 'about',
		'subsection'       => true,
		'customizer_width' => '450px',
		'desc'             => false,
		'fields'           => array(
			array(
				'id'          => 'about_heading',
				'type'        => 'text',
				'title'       => __( 'About', 'wfspa' ),
				'subtitle'    => __( 'about text', 'wfspa' ),
				'desc'        => __( 'Add about text', 'wfspa' ),
				'placeholder' => 'About your heading',
			),
			array(
				'id'          => 'about_heading2',
				'type'        => 'text',
				'title'       => __( 'About', 'wfspa' ),
				'subtitle'    => __( 'about text', 'wfspa' ),
				'desc'        => __( 'Add about text', 'wfspa' ),
				'placeholder' => 'About your site heading 2',
			),			
			array(
				'id'          => 'about_text',
				'type'        => 'textarea',
				'title'       => __( 'About', 'wfspa' ),
				'subtitle'    => __( 'about text', 'wfspa' ),
				'desc'        => __( 'Add about text', 'wfspa' ),
				'placeholder' => 'About your site',
			),
			array(
				'id'       => 'about_img',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'about image', 'wfspa' ),
				'compiler' => 'true',
				'desc'     => __( 'image of about section.', 'wfspa' ),
				'subtitle' => __( 'Upload image of about section', 'wfspa' )
			),
			)
			));
			/***OPTIONS FOR HEADING AND CONTENT OF WELCOME SECTION***/
	Redux::setSection( $opt_name, array(
        'title'            => __( 'welcome note', 'wfspa' ),
        'id'               => 'welcome',
        'customizer_width' => '500px',
        'icon'             => 'el el-pencil ',
    ) );	
	Redux::setSection( $opt_name, array(
		'title'            => __( 'welcome section', 'wfspa' ), 
		'id'               => 'welcomenote',
		'subsection'       => true,
		'customizer_width' => '450px',
		'desc'             => false,
		'fields'           => array(
			array(
				'id'          => 'welcome_heading',
				'type'        => 'text',
				'title'       => __( 'Welcome', 'wfspa' ),
				'subtitle'    => __( 'welcome text', 'wfspa' ),
				'desc'        => __( 'Add welcome text', 'wfspa' ),
				'placeholder' => '',
			),
			array(
				'id'          => 'welcome_note',
				'type'        => 'textarea',
				'title'       => __( 'welcome note', 'wfspa' ),
				'subtitle'    => __( 'welcome text', 'wfspa' ),
				'desc'        => __( 'Add welcome text', 'wfspa' ),
				'placeholder' => '',
			),	
			)
			));	
    Redux::setSection( $opt_name, array(
        'icon'            => 'el el-list-alt',
        'title'           => __( 'Customizer Only', 'wfspa' ),
        'desc'            => __( '<p class="description">This Section should be visible only in Customizer</p>', 'wfspa' ),
        'customizer_only' => true,
        'fields'          => array(
            array(
                'id'              => 'opt-customizer-only',
                'type'            => 'select',
                'title'           => __( 'Customizer Only Option', 'wfspa' ),
                'subtitle'        => __( 'The subtitle is NOT visible in customizer', 'wfspa' ),
                'desc'            => __( 'The field desc is NOT visible in customizer.', 'wfspa' ),
                'customizer_only' => true,
                //Must provide key => value pairs for select options
                'options'         => array(
                    '1' => 'Opt 1',
                    '2' => 'Opt 2',
                    '3' => 'Opt 3'
                ),
                'default'         => '2'
            ),
        )
    ) );
    if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => __( 'Documentation', 'wfspa' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */
    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */
    /*
    *
    * --> Action hook examples
    *
    */
    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );
    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);
    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );
    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );
    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');
    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }
    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;
            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }
            $return['value'] = $value;
            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = 'your custom error message';
            }
            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = 'your custom warning message';
            }
            return $return;
        }
    }
    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }
    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'wfspa' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'wfspa' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );
            return $sections;
        }
    }
    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;
            return $args;
        }
    }
    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';
            return $defaults;
        }
    }
    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );
                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }
