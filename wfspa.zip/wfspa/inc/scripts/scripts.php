<?php
@define( 'PARENT_DIR', get_template_directory() );
	@define( 'PARENT_URL', get_template_directory_uri() );
if ( ! function_exists( 'wf_get_theme_version' ) ) :
	function wf_get_theme_version() {
		$theme_info = wp_get_theme();
		if ( is_child_theme() ) {
			$theme_info = wp_get_theme( $theme_info->parent_theme );
		}
		$theme_version = $theme_info->display( 'Version' );
		return $theme_version;
	}
endif;	
	function wf_add_head_js_css() {
	global $rent_options;
	$theme_version = wf_get_theme_version();
	
	/* Register styles */
	wp_register_style( 'bootstrap', PARENT_URL. '/bootstrap/css/bootstrap.min.css', array(), $theme_version, 'all' );
	wp_enqueue_style( 'font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css', false );
	wp_register_style( 'style', PARENT_URL. '/style.css', array(), $theme_version, 'all' );
	wp_register_style( 'animate', PARENT_URL. '/css/animate.css', array(), $theme_version, 'all' );
	wp_register_style( 'hover', PARENT_URL. '/css/hover.css', array(), $theme_version, 'all' );
	wp_register_style( 'owl', PARENT_URL. '/css/owl.carousel.css', array(), $theme_version, 'all' );
	wp_enqueue_style( 'bootstrap' );
	wp_enqueue_style( 'style' );
	wp_enqueue_style( 'animate' );
	wp_enqueue_style( 'hover' );
	wp_enqueue_style( 'owl' );
		
	/* Enqueue scripts */
	wp_enqueue_script( 'jquery' );	
	wp_enqueue_script( 'wow', PARENT_URL. '/js/wow.js', true, $theme_version );
	wp_enqueue_script( 'owl', PARENT_URL. '/js/owl.carousel.js', true, $theme_version );
	wp_enqueue_script( 'bootstrap', PARENT_URL. '/js/bootstrap.min.js', true, $theme_version );
	wp_enqueue_script( 'coustom', PARENT_URL. '/js/custom.js', true, $theme_version );
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );	
}
add_action('wp_enqueue_scripts', 'wf_add_head_js_css');