<?php
require_once dirname( __FILE__ ) . '/youtube_widget.php';
require_once dirname( __FILE__ ) . '/map_widgets.php';
require_once dirname( __FILE__ ) . '/page_widgets.php';

function spa_widgets_init() {
	 register_sidebar( array(
		'name' => 'Contact footer',
		'id' => 'sidebar',
		'description' => 'Appears in the sidebar area',
		'before_widget' => '<div id="%1$s" class="col-lg-6 col-sm-6 col-md-6 col-xs-12 wow fadeInLeft top-buffer%2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2 class="text-center wow fadeInDown">',
		'after_title' => '</h2>',
	) ); 
	register_sidebar( array(
		'name' => 'Footer ',
		'id' => 'footer',
		'description' => 'Appears in the footer area',
		'before_widget' => '<div id="%1$s" class="col-lg-6 col-md-6 col-sm-6 col-xs-12 top-buffer fadeInLeft widget %2$s"><div id="%1$s" class=" embed-responsive embed-responsive-16by9 widget %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<h2 class="footer-title text-center">',
		'after_title' => '</h2>',
	) );
}
add_action( 'widgets_init', 'spa_widgets_init' );