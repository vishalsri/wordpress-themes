		jQuery(document).ready(function(){
        new WOW().init();
			jQuery("#carousel").owlCarousel({
				autoplay:true,
				//nav:true,
				loop:true,
				margin:15,
				responsive:{
			0:{
				items:1
			},
			600:{
				items:4
			},
				}
			});

		jQuery("[rel='tooltip']").tooltip();
			jQuery('.gallery-images').hover(
				function() {
					jQuery(this).find('.caption').slideDown(500); //.fadeIn(250)
				},
				function() {
					jQuery(this).find('.caption').slideUp(500); //.fadeOut(205)
				}
			);

            //Check to see if the window is top if not then display button
            jQuery(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('.scrollToTop').fadeIn();
                } else {
                    $('.scrollToTop').fadeOut();
                }
            });
            //Click event to scroll to top
            jQuery('.scrollToTop').click(function() {
                jQuery('html, body').animate({
                    scrollTop: 0
                }, 800);
                return false;
            });
			jQuery(".navbar-toggle").click(function(){
				jQuery(".navbar-toggle").attr("aria-expanded","true");
					jQuery("#myNavbar").toggleClass( "collapse" );
			});
        });