<!-- about section -->
<?php  global $theme_options; ?>
	<section class="about">
		<div class="container">
			<?php
							$args = array( 'pagename' => 'about');
								$query = new WP_Query($args  ); ?>
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
			<div class="row">
				 <div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="about-title wow fadeInDown">
						<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
					</div>
				</div>
			</div>
			<div class="row">
				<?php the_content(); ?>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 wow fadeInRight top-buffer">
					<div class="about-image">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('full' , array('class'=>'img-responsive center-block hvr-grow  ')); ?></a>
					</div>
				</div>
			</div>
			<?php endwhile; ?>
		</div>
	</section>