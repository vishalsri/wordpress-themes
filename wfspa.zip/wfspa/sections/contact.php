	<!-- contact section -->
	<?php global $theme_options; ?>
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="contact-title wow fadeInDown">
						<h1><?php _e('Contact','wfspa'); ?></h1>
					</div>
				</div>
			</div>
			<div class="row">
			<?php if(is_active_sidebar('sidebar')) : ?>
							<?php	dynamic_sidebar('sidebar'); ?>
							<?php endif; ?>				
				<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12 wow fadeInRight top-buffer">
					<div class="contact-text">
						<?php echo $theme_options[ 'address-info' ]; ?>
					</div>
					<div class="address">
						<h3><i class="fa fa-home"></i><?php _e('Mailing Address','wfspa'); ?></h3>
						<span><?php echo empty($theme_options['phone'])? "Phone:(123-456-7890)": $theme_options['phone']; ?></span>
					</div>
					<div class="mail">
						<h3><i class="fa fa-envelope"></i><?php _e('E-mail','wfspa'); ?></h3>
						<span><?php echo empty($theme_options['email'])? "lorem@gmail.com": $theme_options['email']; ?></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- section end -->