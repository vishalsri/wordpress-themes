<!-- gallery section -->
	<section class="gallery">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="gallery-title wow fadeInDown">
						<h1><?php _e('Gallery','wfspa'); ?></h1>
					</div>
				</div>
			</div>
					<?php
						$args = array( 'post_type' => 'gallery', 'posts_per_page' => 6 );
						$loop = new WP_Query( $args );
					?> 
			<div class="row top-buffer">
			<?php if ($loop->have_posts()): ?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
				<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center no-padding">
					<div class="gallery-images">
						<div class="caption">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<a href="<?php the_permalink(); ?>"><p><?php _e('Welcome','wfspa'); ?></p></a>
						</div>
					<?php the_post_thumbnail('list-post-thumbnail' , array('class'=>'img-responsive center-block  ')); ?>
					</div>
				</div>
				<?php endwhile; ?>
				<?php endif; ?>				
			</div>
		</div>
	</section>