	<!-- information section -->
		<?php global $theme_options; ?>
	<section class="information">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="information-title wow fadeInDown">
						<h1><?php echo empty($theme_options['info-heading'])? "Beauty Care and Health Information": $theme_options['info-heading']; ?></h1>
					</div>	
				</div>	
			</div>
			<?php
						$args = array( 'post_type' => 'info', 'posts_per_page' => 3 );
						$loop = new WP_Query( $args );
					?> 
			<div class="row">
			<?php if ($loop->have_posts()): ?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
				<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 text-center top-buffer">
					<div class="information-icon">	
						<i class="<?php echo get_post_meta($post->ID, "_icon", true); ?> hvr-bob"></i>
					</div>
					<div class="information-post">
						<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					</div>
					<div class="information-text">
						<p>
							<?php the_excerpt(); ?>
						</p>
					</div>
					<div class="information-link">
						<a href="<?php the_permalink(); ?>"><?php _e('Read More ','wfspa'); ?></a>
					</div>
				</div>
				<?php endwhile; ?>
						<?php endif; ?>			
			</div>
		</div>
	</section>