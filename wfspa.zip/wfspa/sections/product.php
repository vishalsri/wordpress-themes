<!-- product section -->
<?php  global $theme_options; ?>
	<section class="product">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="product-title">
						<h1 class="wow fadeInLeft"><?php echo empty($theme_options['pro-heading'])? "We are Use only Herbal Products": $theme_options['pro-heading']; ?></h1>
						<p class="wow fadeInRight"><?php echo empty($theme_options['pro-content'])? "From Standard Brands only": $theme_options['pro-content']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</section>