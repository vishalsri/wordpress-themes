<?php
global $theme_options; 				
?>	<!-- section start -->	
	<!-- slider section -->
	<section class="slider">	
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no-padding">
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
					  <!-- Indicators -->
					  <ol class="carousel-indicators">
					  <?php $count = 0; ?> <?php  foreach($theme_options['header-slides'] as $slide) { ?>
						<li data-target="#myCarousel" data-slide-to="<?php echo $count; ?>" class="<?php if($count==0) { echo 'active'; } else{echo '';} ?>"></li>
					  <?php  $count++; } ?>									
					  </ol>

					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
					  <?php $counter=0; ?>
							<?php foreach($theme_options['header-slides'] as $slide) { ?>
						<div class="item  <?php if($counter==0) _e('active','wfspa'); else _e('','wfspa'); ?>">
						  <img src="<?php _e($slide['image'], 'wfspa'); ?>" alt="slider1" class="img-responsive center-block" />
						  <?php	$counter++; ?> 
						</div>
							<?php } ?>
						

					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>
