<!-- team section -->
	<section class="team">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
					<div class="team-title wow fadeInDown">
						<h1><?php _e('Our Team','wfspa'); ?></h1>
					</div>
				</div>
			</div>
					<?php
						$args = array( 'post_type' => 'team', 'posts_per_page' => 4 );
						$loop = new WP_Query( $args );
					?> 
			<div class="row">
				<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 top-buffer text-center">
					<div id="carousel" class="owl-carousel owl-theme">
					<?php if ($loop->have_posts()): ?>
					<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
						<div class="item">
							<div class="box hvr-bob">
								<div class="team-image">
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('list-post-thumbnail' , array('class'=>'img-responsive center-block  ')); ?></a>
								</div>
								<div class="team-post">
									<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								</div>
								<div class="team-text">
									<p>
										<?php the_excerpt(); ?>
									</p>
								</div>
								<div class="team-link">
									<a href="<?php the_permalink(); ?>"><?php _e('Read More... ','wfspa'); ?></a>
								</div>
							</div>	
						</div>
						<?php endwhile; ?>
						<?php endif; ?>
					</div>
				</div> 
			</div>
		</div>
	</section>