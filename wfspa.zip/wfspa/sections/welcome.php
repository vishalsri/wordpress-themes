<!-- welcome section -->
<?php
	$args = array( 'pagename' => 'welcome-to-spa-center');
	$query = new WP_Query($args  ); 
		while ( $query->have_posts() ) : $query->the_post(); 
?>
<style>
.welcome {
   background: rgba(0, 0, 0, 0) url("<?php  the_post_thumbnail_url(); ?>") no-repeat scroll center center / cover !important;
}
</style>
<?php global $theme_options;  ?>
	<section class="welcome">
		<div class="color-overly">
			<div class="container">
				<div class="row">
					<div class="col-md-offset-1 col-md-10 col-sm-12 text-center top-buffer">
						<div class="welcome-title wow fadeInDown">
							<h1>
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h1>
						</div>
						<div class="welcome-text top-buffer">
							<p>
								<?php the_content(); ?>
							<?php //echo $theme_options[ 'welcome_note' ]; ?>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endwhile; ?>